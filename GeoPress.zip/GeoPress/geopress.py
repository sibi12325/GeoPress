import pygame
import time
import os
import random
import threading

#initializatiom
queue = []
pygame.init()

#Loading screen
screen = pygame.display.set_mode((0,0), pygame.FULLSCREEN)
os.chdir('OneDrive/Desktop/GeoPress/data/images')
loading_word = pygame.image.load('loading.png').convert_alpha()
loaded = False
screen.fill((250,250,250))
screen.blit(loading_word,(screen.get_width() // 2 - loading_word.get_width() // 2, screen.get_height() // 2 - loading_word.get_height() // 2))
pygame.display.flip()

#initial universal conditions
muted = False
currentState = 0
secretUnlocked = False
stateChanged = False
gaming = False
rectangleanimation = pygame.Rect((0,0,0,0))
littleRectangle1 = pygame.Rect((0,0,0,0))
littleRectangle2 = pygame.Rect((0,0,0,0))
circleanimation = 0
circleLocation = (-1000,-1000)
hint = pygame.Rect((0,0,0,0))
circleHint = 0
trianHints = ((0,0),(0,0),(0,0))
clock = pygame.time.Clock()
fps = 400
circlePressing = False
rectReached = False
circReached = False
triangleDiagonalxInc = screen.get_width() // 32
triangleDiagonalyInc = - screen.get_height()
triangleDiagonalxDec = screen.get_width() // 4 + screen.get_width() // 32
triangleDiagonalyDec = screen.get_height()

#image conversions
icon = pygame.image.load('icon.png')
unmute = pygame.image.load('unmute.png').convert_alpha()
unmute = pygame.transform.smoothscale(unmute,(70,70))
mute = pygame.image.load('mute.png').convert_alpha()
mute = pygame.transform.smoothscale(mute,(70,70))
quit_button = pygame.image.load('quit button.png').convert_alpha()
quit_button = pygame.transform.scale(quit_button,(2*quit_button.get_width() // 3, 3*quit_button.get_height() // 5))
retry_button = pygame.image.load('retry button.png').convert_alpha()
retry_button = pygame.transform.scale(retry_button,(quit_button.get_width(),quit_button.get_height()))
iretry_button = pygame.image.load('retry button inverted.png').convert_alpha()
iretry_button = pygame.transform.smoothscale(iretry_button,(retry_button.get_width(),retry_button.get_height()))
iquit_button = pygame.image.load('quit button inverted.png').convert_alpha()
iquit_button = pygame.transform.smoothscale(iquit_button,(quit_button.get_width(),quit_button.get_height()))
secretmsg = pygame.image.load('cheat_activated.png').convert_alpha()
secretmsg = pygame.transform.scale(secretmsg,(500,200))
help = pygame.image.load('help.png')
help = pygame.transform.smoothscale_by(help,1.5)
question = pygame.image.load('question.png')
question = pygame.transform.smoothscale(question,(70,70))
conheading = pygame.image.load('conheading.png')
conheading = pygame.transform.smoothscale_by(conheading,0.75)
objective = pygame.image.load('objective.png')
objective = pygame.transform.smoothscale_by(objective,0.75)

#shape character loading
os.chdir('shapes')
rectangle = pygame.image.load('rectangle.png').convert()
rectangle = pygame.transform.smoothscale(rectangle,(300,150))
rectangle1 = pygame.image.load('rectangle 1.png').convert()
rectangle1 = pygame.transform.smoothscale(rectangle1,(300,150))
rectangle2 = pygame.image.load('rectangle 2.png').convert()
rectangle2 = pygame.transform.smoothscale(rectangle2,(300,150))
rectangles = [rectangle,rectangle1,rectangle2]
triangle = pygame.image.load('triangle.png').convert_alpha()
triangle = pygame.transform.smoothscale(triangle,(275,275))
triangle1 = pygame.image.load('triangle 1.png').convert_alpha()
triangle1 = pygame.transform.smoothscale(triangle1,(275,275))
triangle2 = pygame.image.load('triangle 2.png').convert_alpha()
triangle2 = pygame.transform.smoothscale(triangle2,(275,275))
triangles = [triangle,triangle1,triangle2]
circle = pygame.image.load('circle.png').convert_alpha()
circle = pygame.transform.smoothscale(circle,(250,250))
circle1 = pygame.image.load('circle 1.png').convert_alpha()
circle1 = pygame.transform.smoothscale(circle1,(250,250))
circle2 = pygame.image.load('circle 2.png').convert_alpha()
circle2 = pygame.transform.smoothscale(circle2,(250,250))
circles = [circle,circle1,circle2]
secret = pygame.image.load('secret.png').convert_alpha()
secret = pygame.transform.smoothscale(secret,(200,200))
os.chdir('..')

shapes = [rectangles,triangles,circles]
rotatedLeftShapes = [[pygame.transform.rotate(rectangles[i], 90) for i in range(3)],[pygame.transform.rotate(triangles[i], 90) for i in range(3)],circles]
rotatedRightShapes = [rotatedLeftShapes[0],[pygame.transform.rotate(triangles[i], -90) for i in range(3)],circles]
upsideDownShapes = [rectangles,[pygame.transform.rotate(triangles[i], 180) for i in range(3)],circles]

#more image conversions
game_over = pygame.image.load('game over.png').convert_alpha()
game_over = pygame.transform.scale_by(game_over,1.5)
pause_title = pygame.image.load('paused.png').convert_alpha()
pause_title = pygame.transform.scale_by(pause_title,1.5)
triangleDiagonal = pygame.image.load('triangle diagonal.png')
triangleDiagonal = pygame.transform.smoothscale(triangleDiagonal,(screen.get_width() // 2, screen.get_height() // 2))
back_button = pygame.image.load('back.png').convert_alpha()
back_button = pygame.transform.smoothscale(back_button,(70,70))
play_button = pygame.image.load('play button.png').convert_alpha()
play_button = pygame.transform.smoothscale(play_button,(2*play_button.get_width() // 3, 2*play_button.get_height() // 3))
iplay_button = pygame.image.load('play button inverted.png').convert_alpha()
iplay_button = pygame.transform.smoothscale(iplay_button,(play_button.get_width(),play_button.get_height()))
title = pygame.image.load('title.png').convert_alpha()
title = pygame.transform.scale_by(title,1.25)

#more universal initialization
volume_lowX = screen.get_width() - screen.get_width() // 16
volume_lowY = screen.get_height() // 32
volume = unmute
colour = (238,232,205)
score = 0
pygame.display.set_icon(icon)
pygame.display.set_caption("GeoPress")

#audio conversions
os.chdir('..')
os.chdir('music')
click_sound = pygame.mixer.Sound('click.wav')
shut_sound = pygame.mixer.Sound('shut.wav')
#-----------------------------------------------attacks choosing----------------------------------------------------------#
def attacks():
    velocity = 0.005
    global gaming,fps
    while gaming:
        chosen = random.randint(0,1)
        if(chosen == 0):
            circlePress(velocity)
        if(chosen == 1):
            rectPress(velocity)
        if(chosen == 2):
            trianglePress(velocity)
        velocity = velocity + 0.005

#-------------------------:------------------------Press Animations----------------------------------------------------------#
#Use mask overlay function in pygame
def trianglePress(velocity):

    time.sleep (1/(5+velocity))

    global rectangleanimation,stateChanged,triangleDiagonalxInc,triangleDiagonalyInc,triangleDiagonalxDec,triangleDiagonalyDec

    initTime = time.time()
    animation_speed = 0.05
    finished = False

    x = screen.get_width() // 3
    y = - screen.get_height() - 10
    rectangle_width = screen.get_width() // 3
    rectangle_height = screen.get_height()
    max = 3*screen.get_height()

    time.sleep(1/(400*velocity))

    while not finished and gaming:

        y = y + velocity

        triangleDiagonalxInc = triangleDiagonalxInc + velocity
        triangleDiagonalyInc = triangleDiagonalyInc + velocity
        triangleDiagonalxDec = triangleDiagonalxDec - velocity
        triangleDiagonalyDec = triangleDiagonalyDec - velocity

        velocity = 1.06*(velocity + animation_speed)

        if(y >= max):
            finished = True
        
        time.sleep(1/100)

        rectangleanimation = pygame.Rect((x, y, rectangle_width, rectangle_height))
        clock.tick(fps)

    stateChanged = False
    rectangleanimation = (0,0,0,0)
    triangleDiagonalxInc = screen.get_width() // 32
    triangleDiagonalyInc = - screen.get_height()
    triangleDiagonalxDec = screen.get_width() // 4 + screen.get_width() // 32
    triangleDiagonalyDec = screen.get_height()

#circ press ()()()()()()()()()()()()()()()()()()()()()()()()()()()()()()()()()())()(()()()()()()()()()()())
def circlePress(velocity):

    time.sleep(1/(5+velocity))
    
    global circleanimation,circle,circleHint,score,fps,circleLocation,stateChanged,circlePressing,circReached,gaming
    circlePressing = True
    looney = pygame.mixer.Sound('looney.wav')
    
    initTime = time.time()

    animation_speed = 0.05
   
    xLocation = random.randint(circle.get_width() // 2,screen.get_width() - circle.get_width() // 2)
    yLocation = random.randint(circle.get_height() // 2,screen.get_height() - circle.get_height() // 2)
    circleLocation = (xLocation,yLocation)
    radius = screen.get_width()
    circleanimation = screen.get_width() + 100
    circleHint = circle.get_width() // 2 + 30
    finished = False

    time.sleep(1/(400*velocity))

    while not finished and gaming:

        if(time.time() - initTime >= 1/(2*velocity)):
            circleHint = 0

        radius = radius - 10*velocity
        velocity = 1.01*(velocity + animation_speed)

        if radius <= ((circle.get_width() / 2 + 30)):
            radius = (circle.get_width() / 2 + 30)
            finished = True

        time.sleep(1/100)

        circleanimation = radius

        clock.tick(fps)

    circReached = True

    if gaming:
        if not muted:
            pygame.mixer.Sound.play(looney)
        time.sleep(0.05)
    score += 1
    circReached = False

    while finished and gaming:

        if radius >= screen.get_width() + 100:
            radius = screen.get_width() + 100
            finished = False
        
        radius = radius + 10*velocity
        
        time.sleep(1/200)
        circleanimation = radius

        clock.tick(fps)
        
    circleanimation = 0
    circleLocation = (-1000,-1000)
    circlePressing = False
    stateChanged = False
    circleHint = 0

#rect press [][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]
def rectPress(velocity):
        
    time.sleep(1/(5+velocity))

    initVelocity = velocity
    initialTime = time.time()
    global rectangleanimation,littleRectangle1,littleRectangle2,hint,stateChanged, score,circleanimation,rectReached,gaming
    finished = False
    sideChosen = random.randint(0,3)
    animation_speed = 0.005

    if(sideChosen == 0):
        x = 0
        y = 0
        rectangle_width = - rectangle.get_height() - 50
        rectangle_height = screen.get_height()
        max = screen.get_width() - rectangle.get_height() - 50
        littleHeight = random.randint(0,screen.get_height() - rectangle.get_width())
        hint = (screen.get_width() - rectangle.get_height() - 50,littleHeight,rectangle.get_height() + 50,rectangle.get_width() + 50)

    elif(sideChosen == 1):
        x = 0
        y = 0
        rectangle_width = screen.get_width()
        rectangle_height = - rectangle.get_height() - 50
        max = screen.get_height() - rectangle.get_height() - 50
        littleWidth = random.randint(0,screen.get_width() - rectangle.get_width())
        hint = (littleWidth,screen.get_height() - rectangle.get_height() - 50,rectangle.get_width() + 50,rectangle.get_height() + 50)
    
    elif(sideChosen == 2):
        x = screen.get_width() + rectangle.get_height() + 50
        y = 0
        rectangle_width = screen.get_width() + 100
        rectangle_height = screen.get_height()
        max = rectangle.get_height() + 50
        littleHeight = random.randint(0,screen.get_height() - rectangle.get_width())
        hint = (0,littleHeight,rectangle.get_height() + 50,rectangle.get_width() + 50)
    
    elif(sideChosen == 3):
        x = 0
        y = screen.get_height() + rectangle.get_height() + 50
        rectangle_width = screen.get_width()
        rectangle_height = screen.get_height() + 100
        max = rectangle.get_height() + 50
        littleWidth = random.randint(0,screen.get_width() - rectangle.get_width())
        hint = (littleWidth,0,rectangle.get_width() + 50,rectangle.get_height() + 50)

    if gaming:
        time.sleep(1/(400*velocity))

    while not finished and gaming:
        if ((time.time() - initialTime) >= 1/(2*velocity)):
            hint = (0,0,0,0)

        # Update the rectangle
        if(sideChosen == 0):
            rectangle_width = rectangle_width + velocity
            velocity = 1.1*(velocity + animation_speed)
            littleWidth = rectangle_width

        elif(sideChosen == 1):
            rectangle_height = rectangle_height + velocity
            velocity = 1.1*(velocity + animation_speed)
            littleHeight = rectangle_height
        
        elif(sideChosen == 2):
            x = x - velocity
            velocity = 1.1*(velocity + animation_speed)
            littleWidth = x - rectangle.get_height() - 50

        elif(sideChosen == 3):
            y = y - velocity
            velocity = 1.1*(velocity + animation_speed)
            littleHeight = y - rectangle.get_height() - 50
        
        if(rectangle_width >= max and sideChosen == 0):
            rectangle_width = max
            littleWidth = rectangle_width
            finished = True

        elif(rectangle_height >= max and sideChosen == 1):
            rectangle_height = max
            littleHeight = rectangle_height
            finished = True

        elif(x <= max and sideChosen == 2):
            x = max
            littleWidth = x - rectangle.get_height() - 50
            finished = True

        elif(y <= max and sideChosen == 3):
            y = max
            littleHeight = y - rectangle.get_height() - 50
            finished = True
        
        time.sleep(1/100)

        #resize
        rectangleanimation = pygame.Rect((x, y, rectangle_width, rectangle_height))
        if(sideChosen == 0 or sideChosen == 2):
            littleRectangle1 = pygame.Rect((littleWidth, 0, rectangle.get_height() + 50, littleHeight))
            littleRectangle2 = pygame.Rect((littleWidth, littleHeight + rectangle.get_width() + 50, rectangle.get_height() + 50, screen.get_height()))
        elif(sideChosen == 1 or sideChosen == 3):
            littleRectangle1 = pygame.Rect((0, littleHeight, littleWidth, rectangle.get_height() + 50))
            littleRectangle2 = pygame.Rect((littleWidth + rectangle.get_width() + 50, littleHeight, screen.get_width(), rectangle.get_height() + 50))
    
        clock.tick(fps)

    rectReached = True

    if gaming:
        if not muted:
            pygame.mixer.Sound.play(shut_sound)
        time.sleep(1/(1000 + initVelocity))
    score += 1
    rectReached = False

    while finished and gaming:

        # Update the width of the rectangle
        if(sideChosen == 0):
            rectangle_width = rectangle_width  - velocity/4
            littleWidth = rectangle_width

        elif(sideChosen == 1):
            rectangle_height = rectangle_height  - velocity/4
            littleHeight = rectangle_height
        
        elif(sideChosen == 2):
            x = x + velocity/4
            littleWidth = x - rectangle.get_height() - 50
        
        elif(sideChosen == 3):
            y = y + velocity/4
            littleHeight = y - rectangle.get_height() - 50

        time.sleep(1/200)

        #resize
        rectangleanimation = pygame.Rect((x, y, rectangle_width, rectangle_height))
        if(sideChosen == 0 or sideChosen == 2):
            littleRectangle1 = pygame.Rect((littleWidth, 0, rectangle.get_height() + 50, littleHeight))
            littleRectangle2 = pygame.Rect((littleWidth, littleHeight + rectangle.get_width() + 50, rectangle.get_height() + 50, screen.get_height()))
        elif(sideChosen == 1 or sideChosen == 3):
            littleRectangle1 = pygame.Rect((0, littleHeight, littleWidth, rectangle.get_height() + 50))
            littleRectangle2 = pygame.Rect((littleWidth + rectangle.get_width() + 50, littleHeight, screen.get_width(), rectangle.get_height() + 50))

        # Cap the width to the maximum width
        if(rectangle_width <= - rectangle.get_height() - 50 and sideChosen == 0):
            rectangle_width = 0
            finished = False
        elif(rectangle_height <= - rectangle.get_height() - 50 and sideChosen == 1):
            rectangle_height = 0
            finished = False
        elif(x >= screen.get_width() + rectangle.get_height() + 50 and sideChosen == 2):
            x = screen.get_width()
            finished = False
        elif(y >= screen.get_height() + rectangle.get_height() + 50 and sideChosen == 3):
            y = screen.get_width()
            finished = False
        clock.tick(fps)

    stateChanged = False
    rectangleanimation = (0,0,0,0)
    littleRectangle1 = (0,0,0,0)
    littleRectangle2 = (0,0,0,0)
    hint = (0,0,0,0)

#-------------------------------------------HELP SCREEN---------------------------------------------------#
class HelpScreen:
    def help_screen():

        global help,back_button,conheading
        helping = True

        font = pygame.font.SysFont('Calibri',45,True)
        wControl = font.render(' W -> flip the shape',1,(0,0,0))
        aControl = font.render(' A -> Tilt shape to the left',1,(0,0,0))
        dControl = font.render(' D -> Tilt shape to the right',1,(0,0,0))
        spaceControl = font.render(' Space -> Change Shape',1,(0,0,0))
        objText = font.render('Quickly move into the shadow ', 1, (0,0,0))
        objText2 = font.render('before the crushers hit you', 1, (0,0,0))

        screen.fill((230,230,230))
        screen.blit(help,(screen.get_width() // 2 - help.get_width() // 2, screen.get_height() // 128))
        screen.blit(back_button,(screen.get_width() // 64, screen.get_height() // 32))
        screen.blit(conheading,(screen.get_width() // 16,screen.get_height() // 4))
        screen.blit(objective,(screen.get_width() - objective.get_width() - screen.get_width() // 16,screen.get_height() // 4))
        screen.blit(objText,(screen.get_width() + 40 - objText.get_width() - screen.get_width() // 16,screen.get_height() // 4 + conheading.get_height() + 10))
        screen.blit(objText2,(screen.get_width() - objText2.get_width() - screen.get_width() // 16,screen.get_height() // 4 + objText.get_height() + 10 +  conheading.get_height() + 10))
        screen.blit(wControl,(screen.get_width() // 16 + 20, screen.get_height() // 4 + conheading.get_height() + 10))
        screen.blit(aControl,(screen.get_width() // 16 + 20, screen.get_height() // 4 + 10 + aControl.get_height() +conheading.get_height() + 10))
        screen.blit(dControl,(screen.get_width() // 16 + 20, screen.get_height() // 4 + 20 +dControl.get_height() + aControl.get_height() + conheading.get_height() + 10))
        screen.blit(spaceControl,(screen.get_width() // 16 + 20, screen.get_height() // 4 + 30 + spaceControl.get_height() + dControl.get_height() + aControl.get_height() +conheading.get_height() + 10))
        pygame.display.flip()

        #coords
        back_lowX = screen.get_width() // 64
        back_lowY = screen.get_height() // 32

        while helping:
            for event in pygame.event.get():
                mouse = pygame.mouse.get_pos()

                if event.type == pygame.QUIT:
                    pygame.quit()

                if(back_lowX <= mouse[0] <= back_lowX + back_button.get_width() and back_lowY <= mouse[1] <= back_lowY + back_button.get_height()):
                    if(event.type == pygame.MOUSEBUTTONDOWN):
                        if(event.button == 1):
                            if not muted:
                                pygame.mixer.Sound.play(click_sound)
                            queue.append(MainMenu.main_menu())
                            helping = False

#-------------------------------------------LOSE SCREEN---------------------------------------------------#
class LoseScreen:
    def lose_screen():
        global score,game_over,back_button, retry_button, iretry_button,secretUnlocked,quit_button,iquit_button
        new_high = False
        font = pygame.font.SysFont('Ariel',70)
        highFont = pygame.font.SysFont('Times New Roman',50)
        scoreDisplay = font.render('Score: ' + str(score - 1),1,(0,0,0))
        os.chdir('..')
        currentHighScore = open('data.txt','r')
        currentHighScore = currentHighScore.read()
        if (score - 1) > int(currentHighScore):
            currentHighScore = score - 1
            new_high = True
            open('data.txt','w').write(str(currentHighScore))
        os.chdir('music')
        
        highScoreDisplay = font.render('High Score: ' + str(currentHighScore),1,(0,0,0))
        newHSMessage = highFont.render('NEW HIGH SCORE',1,(0,0,0))

        onLost = True
        pygame.mixer_music.pause()

        #initial conditions
        currentQuit = pygame.transform.scale_by(quit_button,1.5)
        currentRetry = pygame.transform.scale_by(retry_button,1.5)

        #coords
        back_lowX = screen.get_width() // 64
        back_lowY = screen.get_height() // 32
        quit_lowX = screen.get_width() // 2 - currentQuit.get_width() // 2
        retry_lowY = screen.get_height() // 2 + 60 - currentQuit.get_height() // 2
        quit_lowY = screen.get_height() // 2 + 60 + currentQuit.get_height() // 2

        #main pause loop
        while onLost:

            #instantaneous screen
            paused_colour = (193,205,205)
            screen.fill(paused_colour)
            screen.fill(paused_colour,(screen.get_width() - screen.get_width() // 16, screen.get_height() // 32,70,70))
            screen.blit(back_button,(screen.get_width() // 64, screen.get_height() // 32))
            screen.blit(game_over,(screen.get_width() // 2 - game_over.get_width() // 2, screen.get_height() // 6 - game_over.get_height() // 2))
            screen.blit(currentRetry,(quit_lowX, retry_lowY))
            screen.blit(currentQuit,(quit_lowX, quit_lowY))
            screen.blit(scoreDisplay,(screen.get_width() // 2 - scoreDisplay.get_width() // 2,screen.get_height() // 3 - 30))
            screen.blit(highScoreDisplay,(screen.get_width() // 2 - highScoreDisplay.get_width() // 2,screen.get_height() // 3 + scoreDisplay.get_height() - 20))
            if new_high:
                screen.blit(newHSMessage,(screen.get_width() // 2 - newHSMessage.get_width() // 2,screen.get_height() // 3 + scoreDisplay.get_height() + highScoreDisplay.get_height() - 15))

            pygame.display.flip()

            #input events
            for event in pygame.event.get():
                pygame.mouse.set_visible(True)
                mouse = pygame.mouse.get_pos()
   
                if(back_lowX <= mouse[0] <= back_lowX + back_button.get_width() and back_lowY <= mouse[1] <= back_lowY + back_button.get_height()):
                    if(event.type == pygame.MOUSEBUTTONDOWN):
                        if(event.button == 1):
                            queue.append(MainMenu.main_menu())
                            secretUnlocked = False
                            pygame.mixer_music.unload()
                            onLost = False

                if(quit_lowX <= mouse[0] <= (screen.get_width() // 2 + currentQuit.get_width() // 2) and quit_lowY <= mouse[1] <= quit_lowY + currentRetry.get_height()):
                    currentQuit = pygame.transform.scale_by(iquit_button,1.5)
                    if(event.type == pygame.MOUSEBUTTONDOWN):
                        if(event.button == 1):
                            pygame.quit()
                else:
                    currentQuit = pygame.transform.scale_by(quit_button,1.5)
                
                if(quit_lowX <= mouse[0] <= (screen.get_width() // 2 + currentQuit.get_width() // 2) and (retry_lowY) <= mouse[1] <= (retry_lowY + 25 + retry_button.get_height())):
                    currentRetry = pygame.transform.scale_by(iretry_button,1.5)
                    if(event.type == pygame.MOUSEBUTTONDOWN):
                        if(event.button == 1):
                            onLost = False
                            score = 0
                            queue.append(GameScreen.game(mouse))
                else:
                    currentRetry = pygame.transform.scale_by(retry_button,1.5)
            clock.tick(fps)

    
# ------------------------------------------- PAUSE MENU -------------------------------------------------#
class PauseMenu:
    def pause_menu():

        #global variables
        global pause_title,back_button,volume,muted,unmute,mute,volume_lowX,volume_lowY,secretUnlocked,retry_button,iretry_button,score,currentState
        
        paused = True
        cheatInput = ['-','-','-','-','-','-','-','-']
        inputCount = 0
        pygame.mixer_music.pause()

        #initial conditions
        currentQuit = pygame.transform.scale_by(quit_button,1.5)
        currentRetry = pygame.transform.scale_by(retry_button,1.5)
        printmsg = True

        #coords
        back_lowX = screen.get_width() // 64
        back_lowY = screen.get_height() // 32

        #main pause loop
        while paused:

            #top secret
            cheatStringHalf = ''.join(cheatInput)
            cheatString = cheatStringHalf + cheatStringHalf
            if "bigbooty" in cheatString and printmsg:
                if not muted:
                    pygame.mixer.Sound.play(click_sound)
                secretUnlocked = True
                printmsg = False
            
            #instantaneous screen
            paused_colour = (193,205,205)
            screen.fill(paused_colour)
            screen.fill(paused_colour,(screen.get_width() - screen.get_width() // 16, screen.get_height() // 32,70,70))
            screen.blit(volume,(screen.get_width() - screen.get_width() // 16, screen.get_height() // 32))
            screen.blit(back_button,(screen.get_width() // 64, screen.get_height() // 32))
            screen.blit(pause_title,(screen.get_width() // 2 - pause_title.get_width() // 2, screen.get_height() // 4 - pause_title.get_height() // 2))
            screen.blit(currentRetry,(screen.get_width() // 2 - currentRetry.get_width() // 2, screen.get_height() // 2 - currentRetry.get_height() // 2))
            screen.blit(currentQuit,(screen.get_width() // 2 - currentQuit.get_width() // 2, screen.get_height() // 2 - currentRetry.get_height() // 2 + currentRetry.get_height() + 10))

            if(secretUnlocked):
                screen.blit(secretmsg,(screen.get_width() // 2 - secretmsg.get_width() // 2, 3*screen.get_height() // 5 + currentQuit.get_height()))

            pygame.display.flip()

            #input events
            for event in pygame.event.get():
                pygame.mouse.set_visible(True)
                mouse = pygame.mouse.get_pos()

                #hovering over volume button
                if(volume_lowX <= mouse[0] <= volume_lowX + volume.get_width() and volume_lowY <= mouse[1] <= volume_lowY + volume.get_height()):
                    if(event.type == pygame.MOUSEBUTTONDOWN):
                        if(event.button == 1):      
                            pygame.mixer.Sound.play(click_sound)
                            if(not muted):
                                muted = True
                                volume = mute
                            elif(muted):
                                muted = False
                                volume = unmute
                
                if(back_lowX <= mouse[0] <= back_lowX + back_button.get_width() and back_lowY <= mouse[1] <= back_lowY + back_button.get_height()):
                    if(event.type == pygame.MOUSEBUTTONDOWN):
                        if(event.button == 1):
                            m1 = MainMenu
                            queue.append(m1.main_menu())
                            secretUnlocked = False
                            pygame.mixer_music.unload()
                            paused = False

                if(event.type == pygame.KEYDOWN):
                    if(event.key == pygame.K_ESCAPE):
                        pygame.mixer_music.unpause()
                        queue.append(GameScreen.game(mouse))
                        paused = False

                    else:
                        cheatInput[inputCount] = event.unicode
                        inputCount = (inputCount + 1) % 8

                if((screen.get_width() // 2 - currentRetry.get_width() // 2) <= mouse[0] <= (screen.get_width() // 2 + currentRetry.get_width() // 2) and (screen.get_height() // 2 - currentRetry.get_height() // 2 + currentRetry.get_height() + 10) <= mouse[1] <= (screen.get_height() // 2 + currentQuit.get_height() // 2 + currentRetry.get_height() + 10)):
                    currentQuit = pygame.transform.scale_by(iquit_button,1.5)
                    if(event.type == pygame.MOUSEBUTTONDOWN):
                        if(event.button == 1):
                            pygame.quit()
                else:
                    currentQuit = pygame.transform.scale_by(quit_button,1.5)
                
                if((screen.get_width() // 2 - currentRetry.get_width() // 2) <= mouse[0] <= (screen.get_width() // 2 + currentRetry.get_width() // 2) and (screen.get_height() // 2 - currentRetry.get_height() // 2) <= mouse[1] <= (screen.get_height() // 2 + currentQuit.get_height() // 2)):
                    currentRetry = pygame.transform.scale_by(iretry_button,1.5)
                    if(event.type == pygame.MOUSEBUTTONDOWN):
                        if(event.button == 1):
                            paused = False
                            score = 0
                            currentState = 0
                            queue.append(GameScreen.game(mouse))
                else:
                    currentRetry = pygame.transform.scale_by(retry_button,1.5)
            clock.tick(fps)

# ------------------------------------------- GAME SCREEN -------------------------------------------------#
class GameScreen:

    def game(mouse):
        global score,fps,secretUnlocked,rectangles,littleRectangle1,littleRectangle2,rectangleanimation,triangles,circles,secret,secretmsg,gaming,circleHint,circleanimation,circleLocation,circlePressing
        global muted,shapes,rotatedLeftShapes,rotatedRightShapes,upsideDownShapes,currentState,stateChanged,circReached,triangleDiagonalxInc,triangleDiagonalyInc,triangleDiagonalxDec,triangleDiagonalyDec,triangleDiagonal
        font = pygame.font.SysFont('Calibri',100)
        scoreColour = (88,82,55)
        scoreDisplay = font.render(str(score),1,scoreColour)
        triangleDiagonal1 = pygame.transform.rotate(triangleDiagonal,-30)
        triangleDiagonal2 = pygame.transform.rotate(triangleDiagonal,30)
        triangleDiagonal3 = pygame.transform.rotate(triangleDiagonal,-30)
        triangleDiagonal4 = pygame.transform.rotate(triangleDiagonal,30)

        pygame.mouse.set_visible(False)

        #sounds
        if not secretUnlocked:
            pygame.mixer_music.load('game bg music.wav')
        else:
            pygame.mixer_music.load('banquet of booty.wav')
        shapeSwitch = pygame.mixer.Sound('shape switch.wav')
        breakSound = pygame.mixer.Sound('break.wav')
        
        #initial conditionals

        currentShapePosition = 0
        currentShape = shapes[currentShapePosition][currentState]
        printmsg = True
        gameLoop = True
        gaming = True
        crush = threading.Thread(target=attacks)
        crush.start()
        x,y = mouse
        shap = pygame.Rect((0,0,0,0))
        currentRotation = shapes
        d_down = False
        a_down = False
        w_down = False

        #music
        pygame.mixer_music.play(-1)
        if(muted):
            pygame.mixer_music.pause()

        #main game loop
        while gameLoop:

            #secret unlocked
            if(secretUnlocked and printmsg):
                currentShape = secret

            #instantaneous screen
            if(circlePressing):
                screen.fill((40,43,43))
            else:
                screen.fill(colour)

            topCircle = pygame.Rect(circleLocation[0] - circleanimation - 5, circleLocation[1] - circleanimation - 5, 2*circleanimation + 10, 5)
            leftCircle = pygame.Rect(circleLocation[0] - circleanimation - 5, circleLocation[1] - circleanimation - 5, 5,2*circleanimation + 10)
            bottomCircle = pygame.Rect(circleLocation[0] - circleanimation - 5, circleLocation[1] + circleanimation + 5, 2*circleanimation + 10, 5)
            rightCircle = pygame.Rect(circleLocation[0] + circleanimation + 5, circleLocation[1] - circleanimation - 5, 5,2*circleanimation + 10)

            if((((shap.colliderect(rectangleanimation) or shap.colliderect(littleRectangle1) or shap.colliderect(littleRectangle2)) or (rectReached and currentShapePosition != 0)) or ((shap.colliderect(topCircle) or shap.colliderect(bottomCircle) or shap.colliderect(leftCircle) or shap.colliderect(rightCircle)) or (circReached and currentShapePosition != 2))) and not stateChanged and not secretUnlocked):
                if not muted:
                    pygame.mixer.Sound.play(breakSound)
                currentState = currentState + 1
                stateChanged = True
                if(currentState == 3):
                    currentState = 0
                    gaming = False

                    crush.join()
                    queue.append(LoseScreen.lose_screen())
                    
                    gameLoop = False
                currentShape = currentRotation[currentShapePosition]
                currentShape = currentShape[currentState]
            
            pygame.draw.rect(screen,(40,43,43),rectangleanimation)
            pygame.draw.rect(screen,(40,43,43),littleRectangle1)
            pygame.draw.rect(screen,(40,43,43),littleRectangle2)
            pygame.draw.rect(screen,(200,194,167),hint)
            pygame.draw.circle(screen,colour,circleLocation,circleanimation)
            pygame.draw.circle(screen,(200,194,167),circleLocation,circleHint)
            screen.blit(triangleDiagonal1,(1.5*triangleDiagonalxInc,triangleDiagonalyInc))
            screen.blit(triangleDiagonal2,(1.5*triangleDiagonalxDec,triangleDiagonalyInc))
            screen.blit(triangleDiagonal3,(1.5*triangleDiagonalxDec,triangleDiagonalyDec))
            screen.blit(triangleDiagonal4,(1.5*triangleDiagonalxInc,triangleDiagonalyDec))

            screen.blit(currentShape,(x - currentShape.get_width() // 2,y - currentShape.get_height() // 2))
            screen.blit(scoreDisplay,(screen.get_width() // 2 - scoreDisplay.get_width() // 2, 50))

            for event in pygame.event.get(): 

                mouse2 = pygame.mouse.get_pos()
                
                if(event.type == pygame.KEYDOWN):

                    #shape switch
                    if(event.key == pygame.K_SPACE and not secretUnlocked):
                        currentShapePosition = (currentShapePosition + 1) % 3
                        if not muted:
                            pygame.mixer.Sound.play(shapeSwitch)
                    
                    #shape rotaters
                    if(event.key == pygame.K_d):
                        d_down = True
                
                    if(event.key == pygame.K_a):
                        a_down = True                             

                    if(event.key == pygame.K_w):
                        w_down = True 

                    #pause menu
                    if(event.key == pygame.K_ESCAPE):
                        gaming = False
                        crush.join()
                        if not muted:
                            pygame.mixer.Sound.play(click_sound)
                        queue.append(PauseMenu.pause_menu())
                        gameLoop = False
                        

                if(event.type == pygame.KEYUP):
                    if event.key == pygame.K_d:
                        d_down = False
                    if event.key == pygame.K_a:
                        a_down = False
                    if event.key == pygame.K_w:
                        w_down = False
                
                if(event.type == pygame.QUIT):
                    pygame.quit()

                x,y = mouse2
                if (x > (screen.get_width() - currentShape.get_width() // 2)):
                    x = screen.get_width() - currentShape.get_width() // 2
                if(x < (currentShape.get_width() // 2)):
                    x = currentShape.get_width() // 2
                if(y > (screen.get_height() - currentShape.get_height() // 2)):
                    y = screen.get_height() - currentShape.get_height() // 2
                if(y < currentShape.get_height() // 2):
                    y = currentShape.get_height() // 2

                shap = (x - currentShape.get_width() // 2,y - currentShape.get_height() // 2,currentShape.get_width(),currentShape.get_height())
                shap = pygame.Rect(shap)

                currentShape = shapes[currentShapePosition]
                currentRotation = shapes
                currentShape = currentShape[currentState]

                if d_down:
                    currentShape = rotatedLeftShapes[currentShapePosition]
                    currentRotation = rotatedLeftShapes
                    currentShape = currentShape[currentState]     
                
                if a_down:
                    currentShape = rotatedRightShapes[currentShapePosition] 
                    currentRotation = rotatedRightShapes
                    currentShape = currentShape[currentState] 
                
                if w_down:
                    currentShape = upsideDownShapes[currentShapePosition]
                    currentRotation = upsideDownShapes
                    currentShape = currentShape[currentState] 

            scoreDisplay = font.render(str(score),1,scoreColour)
            pygame.display.flip()
            clock.tick(fps)
            

# ------------------------------------------- MAIN MENU -------------------------------------------------#
class MainMenu():

    #coordinates
    play_lowX = screen.get_width() // 2 - play_button.get_width() // 2
    play_lowY = screen.get_height() // 2
    quit_lowX = screen.get_width() // 2 - quit_button.get_width() // 2
    quit_lowY = screen.get_height() // 2 + 5*play_button.get_height() // 4

    def main_menu():

        global currentState,stateChanged,secretUnlocked,volume,volume_lowX,volume_lowY,muted,title,question,objective,score

        secretUnlocked = False

        currentState = 0
        stateChanged = False

        #initial menu conditions
        mainLoop = True
        play = play_button
        quit = quit_button

        #coords
        question_lowX = screen.get_width() // 64
        question_lowY = screen.get_height() // 32

        #bg music
        pygame.mixer_music.load('bg music.wav')
        pygame.mixer_music.play(-1)

        if muted:
            pygame.mixer_music.pause()

        #main menu loop
        while mainLoop:
        
            #initialising buttons
            screen.fill(colour)
            screen.blit(title,(screen.get_width() // 2 - title.get_width() // 2, screen.get_height() // 4))
            screen.blit(play,(screen.get_width() // 2 - play.get_width() // 2,screen.get_height() // 2))
            screen.blit(quit,(screen.get_width() // 2 - quit.get_width() // 2,screen.get_height() // 2 + 5*play.get_height() // 4))
            screen.fill(colour,(screen.get_width() - screen.get_width() // 16, screen.get_height() // 32,70,70))
            screen.blit(volume,(screen.get_width() - screen.get_width() // 16, screen.get_height() // 32))
            screen.blit(question,(screen.get_width() // 64, screen.get_height() // 32))
            pygame.display.flip()

            for event in pygame.event.get():
                mouse = pygame.mouse.get_pos()
                pygame.mouse.set_visible(True)

                if(question_lowX <= mouse[0] <= question_lowX + question.get_width() and question_lowY <= mouse[1] <= question_lowY + question.get_height()):
                    if(event.type == pygame.MOUSEBUTTONDOWN):
                        if(event.button == 1):
                            if not muted:
                                pygame.mixer.Sound.play(click_sound)
                            pygame.mixer_music.unload()
                            queue.append(HelpScreen.help_screen())
                            mainLoop = False

                #close condition
                if(event.type == pygame.QUIT):
                    pygame.quit()

                #hovering over volume button
                if(volume_lowX <= mouse[0] <= volume_lowX + volume.get_width() and volume_lowY <= mouse[1] <= volume_lowY + volume.get_height()):
                    if(event.type == pygame.MOUSEBUTTONDOWN):
                        if(event.button == 1):
                            pygame.mixer.Sound.play(click_sound)
                            if(not muted):
                                muted = True
                                pygame.mixer_music.pause()
                                volume = mute
                            elif(muted):
                                muted = False
                                pygame.mixer_music.unpause()
                                volume = unmute

                #hovering over play button
                if(MainMenu.play_lowX <= mouse[0] <= MainMenu.play_lowX + play.get_width() and MainMenu.play_lowY <= mouse[1] <= MainMenu.play_lowY + play.get_height()):
                    play = iplay_button
                    if(event.type == pygame.MOUSEBUTTONDOWN):
                        if(event.button == 1):
                            if not muted:
                                pygame.mixer.Sound.play(click_sound)
                            score = 0
                            pygame.mixer_music.unload()
                            queue.append(GameScreen.game(mouse))
                            mainLoop = False
                        
                    if(muted):
                        pygame.mixer_music.pause()
                        volume = mute

                else:
                    play = play_button
                
                #hovering over quit button
                if(MainMenu.quit_lowX <= mouse[0] <= MainMenu.quit_lowX + quit.get_width() and MainMenu.quit_lowY <= mouse[1] <= MainMenu.quit_lowY + quit.get_height()):
                    quit = iquit_button
                    if(event.type == pygame.MOUSEBUTTONDOWN):
                        if(event.button == 1):
                            pygame.quit()
                else:
                    quit = quit_button
            clock.tick(fps)


#adding main menu as starting screen
queue.append(MainMenu.main_menu())

#queue storing current game state
while not queue:
    queue.pop(0)
            